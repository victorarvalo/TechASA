﻿namespace TechASAApp.Services
{
    public class AuthMessageSenderOptions
    {
        public string? SendGridKey { get; set; }
        public string? email { get; set; }
    }
}
