﻿using Microsoft.AspNetCore.Identity;

namespace TechASAApp.Models
{
    public class ApplicationUser : IdentityUser
    {

    }
}
