﻿namespace TechASAApp.Models
{
    public class personal
    {
        public string name { get; set; }
        public string lastName { get; set; }
        public int age { get; set; }
        public string bordDate { get; set; }
        public string bornPlace { get; set; }
        public string idDocument { get; set; }
        public string address { get; set; }
        public string celPhone { get; set; }
        public List<string> email { get; set; }
    }
}
